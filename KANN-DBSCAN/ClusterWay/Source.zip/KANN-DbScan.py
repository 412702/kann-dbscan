# -*- coding: utf-8 -*-
#  creating on Oct 21 2019
import time
import math
import copy
import numpy as np
from sklearn.cluster import DBSCAN
from matplotlib import pyplot
import matplotlib.pyplot as plt


def loadDataSet(fileName, splitChar='\t'):
    """
    description: 从文件读入数据集
    :param fileName: 文件名
    :param splitChar: 字符串分隔符
    :return: 数据集
    """
    dataSet = []
    with open(fileName) as fr:
        for line in fr.readlines():
            curline = line.strip().split(splitChar)
            fltline = list(map(float, curline))
            dataSet.append(fltline)
    return dataSet


def dist(a,b):
    """
    description: 用来计算两个样本点之间的距离
    :param a: 样本点
    :param b: 样本点
    :return: 两个样本点之间的距离
    """
    return math.sqrt(math.pow(a[0]-b[0],2) + math.pow(a[1]-b[1],2))


def returnDk(matrix,k):
    """
    description: 用来计算第K最近的距离集合
    :param matrix: 距离矩阵
    :param k: 第k最近
    :return: 第k最近距离集合
    """
    Dk = []
    for i in range(len(matrix)):
        Dk.append(matrix[i][k]) #取出每一行的第k列
    return Dk


def returnDkAverage(Dk):
    """
    description: 求第K最近距离集合的平均值
    :param Dk: k-最近距离集合
    :return: Dk的平均值
    """
    sum = 0
    for i in range(len(Dk)):
        sum = sum + Dk[i]
    return sum/len(Dk)


def CalculateDistMatrix(dataset): #对KANN来说必须先求距离矩阵，
    """
    description: 计算距离矩阵
    :param dataset: 数据集
    :return: 距离矩阵
    """
    DistMatrix = [[0 for j in range(len(dataset))] for i in range(len(dataset))]    #建立一个dataSet大小的list
    for i in range(len(dataset)):
        for j in range(len(dataset)):
            DistMatrix[i][j] = dist(dataset[i], dataset[j])
    return DistMatrix


def returnEpsCandidate(dataSet, DistMatrix):
    """
    description: 计算Eps候选列表
    :param dataSet: 数据集
    :return: eps候选集合
    """
    #DistMatrix = CalculateDistMatrix(dataSet)
    tmp_matrix = copy.deepcopy(DistMatrix)#对象拷贝，深拷贝，相当于完全复制了一个新的对象
    for i in range(len(tmp_matrix)):
        tmp_matrix[i].sort()    #对每一行元素进行升序排列，即找到该行的第1~n近邻元素
    EpsCandidate = []   #排序完，第i**列**即为所有点的第i近邻距离，此时对所有点第i近邻取平均，得到第i平均近邻，作为Eps的候选项
    for k in range(1,len(dataSet)):
        Dk = returnDk(tmp_matrix,k) #第K近邻距离集合
        DkAverage = returnDkAverage(Dk) #第K近邻的平均距离，求均值
        EpsCandidate.append(DkAverage)  #把求到的平均值塞进EpsCandidate里面
    return EpsCandidate


def returnMinptsCandidate(DistMatrix,EpsCandidate):
    """
    description: 计算Minpts候选列表
    :param DistMatrix: 距离矩阵
    :param EpsCandidate: Eps候选列表
    :return: Minpts候选列表
    """
    MinptsCandidate = []
    for k in range(len(EpsCandidate)):
        tmp_eps = EpsCandidate[k]
        tmp_count = 0
        for i in range(len(DistMatrix)):
            for j in range(len(DistMatrix[i])):
                if DistMatrix[i][j] <= tmp_eps:
                    tmp_count = tmp_count + 1
        MinptsCandidate.append(tmp_count/len(dataSet))  #求平均
    return MinptsCandidate


def returnClusterNumberList(dataset,EpsCandidate,MinptsCandidate): #生成最终聚类簇
    """
    description: 计算聚类后的类别数目 
    :param dataset: 数据集
    :param EpsCandidate: Eps候选列表
    :param MinptsCandidate: Minpts候选列表
    :return: 聚类数量列表
    """
    np_dataset = np.array(dataset)  #将dataset转换成numpy_array的形式，多维数组
    ClusterNumberList = []
    for i in range(len(EpsCandidate)):
        modle = DBSCAN(eps= EpsCandidate[i],min_samples= MinptsCandidate[i])    #这里是调用的DBSCAN类生成一个DBSCAN对象,生成DBSCAN聚类模型；可以选择另一种做法直接调用dbscan方法，结果一样
        clustering = modle.fit(np_dataset)  #对数据集进行聚类，要求数据集形状（n_samples，n_features）的数组或稀疏矩阵，返回值仍然是一个DBSCAN对象
        num_clustering = max(clustering.labels_)    #.labels_ 为DBSCAN的聚类标签，也就是每一个类的序号，取最大值，即为聚类数目
        ClusterNumberList.append(num_clustering)    #把聚类数量放进list里面
    return ClusterNumberList

def returnDensity(Eps, Minpts):
    """
    description: 计算候选列表的密度阈值，density = MinPtds/(ΠEps²)
    :param Eps: Eps候选列表
    :param Minpts: Minpts候选列表
    :return: 对应的密度阈值列表
    """
    density = []
    if(len(Eps) == len(Minpts)):
        for i in range(len(Eps)):
            density_tmp_value = Minpts[i]/(math.pi*Eps[i]*Eps[i])
            density.append(density_tmp_value)
    return density

def showInitPoint(data):
    """
    description: 将数据集初始化以散点图显示出来
    :param data: 数据集列表
    :return: 
    """
    data = np.mat(data).transpose()
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.scatter(data[0, :].flatten().A[0], data[1, :].flatten().A[0], c='black', s=5)
    plt.show()


def showRelationLineChart(y_data, y_name = "Eps"):
    """
    description: 将给定的数据列表以折线图形式画出
    :param y_data: 数据列表，纵坐标取值集合
    :param y_name: y轴名
    :return: 
    """
    x=range(len(y_data))
    plt.grid(linestyle='--')  # 生成网格,网格线样式为 端虚线
    plt.plot(x,y_data)
    #plt.plot()  x是可选的，如果x没有，将默认是从0到n-1，也就是y_data的索引，maker为目标点显示样式，mec(全名markeredgecolor)，也就是maker的边缘颜色
    #plt.xticks(x, dividedByScale(x,scale = getScale(len(x))))    #第一个参数表示坐标轴上对应位置，第二个参数表述第一个参数表示位置上显示的值,如([0,3],[1,4]),表示0~3位置上显示1~4
    #真辛酸，上面那根本没有必要，也算是踩一个坑吧
    plt.margins(0)  #设置或获取自动缩放量，挺重要的，要不很难看
    #plt.subplots_adjust(bottom=0.10)    #调整子图布局。
    plt.xlabel('K value') #X轴标签
    plt.ylabel(y_name) #Y轴标签
    #pyplot.yticks() #可以设置y轴的范围，默认是最小和最大值之间的区间，这里没必要设置
    plt.title("The Relation of the "+y_name+" and K Value") #标题
    plt.show()
    
def returnBestClusterNum(ClusterNumberList, expectConstantTimes = 3):
    """
    description: 求聚类结果"收敛"时，包含的簇的个数
    :param ClusterNumberList: K值对应的聚类簇
    :param expectConstantTimes: 期望最小连续数，作为最佳聚类簇数
    :return: 
    """
    constantTimes = 1
    maxConstantTimes = 1
    maxConstantTimesIndex = 0
    for i in range(1,len(ClusterNumberList)):
        if ClusterNumberList[i] == ClusterNumberList[i-1]:
            constantTimes += 1
            if constantTimes > maxConstantTimes:
                maxConstantTimes = constantTimes
                maxConstantTimesIndex = i
        else:
            constantTimes = 1
            if ClusterNumberList[i] == 0:
                break
    if maxConstantTimes < expectConstantTimes:
        maxConstantTimes = 0
    return maxConstantTimes, maxConstantTimesIndex
    
if __name__ == '__main__':
    start = time.perf_counter()
    dataSet = loadDataSet('788points.txt', splitChar=',')   #此处的dataSet为n行两列的list
    showInitPoint(dataSet)     #把初始点先画出来
    #print(dataSet)
    #print(np.shape(dataSet))
    #print(np.mat(dataSet).transpose())
    DistMatrix = CalculateDistMatrix(dataSet)   #获得距离矩阵，方便用KANN
    EpsCandidate = returnEpsCandidate(dataSet, DistMatrix)  #获得Eps候选集
    MinptsCandidate = returnMinptsCandidate(DistMatrix,EpsCandidate)    #获得MinPts候选集
    Density = returnDensity(EpsCandidate, MinptsCandidate)
    ClusterNumberList = returnClusterNumberList(dataSet,EpsCandidate,MinptsCandidate)   #获得最终聚类结果
    maxConstantTimes, bestK = returnBestClusterNum(ClusterNumberList, expectConstantTimes = 3)
    
    showRelationLineChart(EpsCandidate, "Eps")    #画出K与Eps候选集的关系
    showRelationLineChart(MinptsCandidate, "MinPts")    #画出K与MinPts候选集的关系
    showRelationLineChart(Density, "Density Result")    #画出K与Density的关系
    showRelationLineChart(ClusterNumberList, "Cluster Result Number")   #画出K与最终聚类结果聚类簇数的关系
    #print("\nEpsCandidate is:",EpsCandidate)
    #print("\nMinptsCandidate is: ",MinptsCandidate)
    #print("\ncluster number list is:",ClusterNumberList)
    print("The best Eps: ", EpsCandidate[bestK])
    print("The best Minpts: ", ClusterNumberList[bestK])
    print("Cluster number: ",ClusterNumberList[bestK])
    print("The maxConstantTimes: ", maxConstantTimes)
    print("The best K: ", bestK)
    end = time.perf_counter()
    print('finish all in %s' % str(end - start))
    